# TASK 2 

# importing libraries



```python
#importing important libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
import seaborn as sns
```

# read the data set



```python
#reading the dataset
df=pd.read_csv(r'http://bit.ly/w-data')
```


```python
#reading the first five rows of the datasets
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <td>1</td>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <td>2</td>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <td>3</td>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <td>4</td>
      <td>3.5</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>




```python
#reading the last five datsets
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>20</td>
      <td>2.7</td>
      <td>30</td>
    </tr>
    <tr>
      <td>21</td>
      <td>4.8</td>
      <td>54</td>
    </tr>
    <tr>
      <td>22</td>
      <td>3.8</td>
      <td>35</td>
    </tr>
    <tr>
      <td>23</td>
      <td>6.9</td>
      <td>76</td>
    </tr>
    <tr>
      <td>24</td>
      <td>7.8</td>
      <td>86</td>
    </tr>
  </tbody>
</table>
</div>




```python
#information about the dataset
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>25.000000</td>
      <td>25.000000</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>5.012000</td>
      <td>51.480000</td>
    </tr>
    <tr>
      <td>std</td>
      <td>2.525094</td>
      <td>25.286887</td>
    </tr>
    <tr>
      <td>min</td>
      <td>1.100000</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>2.700000</td>
      <td>30.000000</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>4.800000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>7.400000</td>
      <td>75.000000</td>
    </tr>
    <tr>
      <td>max</td>
      <td>9.200000</td>
      <td>95.000000</td>
    </tr>
  </tbody>
</table>
</div>



# shape of dataset


```python
#no of rows and columns of the datsets
df.shape
```




    (25, 2)




```python
#sum of null data 
df.isnull().sum()
```




    Hours     0
    Scores    0
    dtype: int64



# Plotting histogram 


```python
plt.hist('Scores',data=df,bins=10)
plt.show()
```


![png](output_12_0.png)



```python
sns.lmplot(x='Hours',y='Scores',data=df)
plt.show()
```


![png](output_13_0.png)



```python
#pairplot with seaborn
sns.pairplot(df,hue='Hours',palette='rainbow')
```

    C:\ProgramData\Anaconda3\lib\site-packages\numpy\core\_methods.py:140: RuntimeWarning: Degrees of freedom <= 0 for slice
      keepdims=keepdims)
    C:\ProgramData\Anaconda3\lib\site-packages\numpy\core\_methods.py:132: RuntimeWarning: invalid value encountered in double_scalars
      ret = ret.dtype.type(ret / rcount)
    C:\ProgramData\Anaconda3\lib\site-packages\statsmodels\nonparametric\kde.py:487: RuntimeWarning: invalid value encountered in true_divide
      binned = fast_linbin(X, a, b, gridsize) / (delta * nobs)
    C:\ProgramData\Anaconda3\lib\site-packages\statsmodels\nonparametric\kdetools.py:34: RuntimeWarning: invalid value encountered in double_scalars
      FAC1 = 2*(np.pi*bw/RANGE)**2
    




    <seaborn.axisgrid.PairGrid at 0x1e9d35f3e08>




![png](output_14_2.png)



```python
#jointplot with sns
sns.jointplot('Hours','Scores',data=df,kind='reg')
```




    <seaborn.axisgrid.JointGrid at 0x1e9d4d1bac8>




![png](output_15_1.png)


# importing sklearn


```python

from sklearn.model_selection import train_test_split
```


```python
x=df.iloc[:,:-1].values
y=df.iloc[:,1].values
```

# splitting the data set


```python
train_x,test_x,train_y,test_y=train_test_split(x,y,test_size=0.2)
```


```python
#importing linear regression 
from sklearn.linear_model import LinearRegression
```


```python
Lreg=LinearRegression()
```


```python
#fitting the model 
Lreg.fit(train_x,train_y)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=False)




```python
#accuracy on the test model
Lreg.score(train_x,train_y)
```




    0.9522312444716324



# Predictions for the test dataset


```python
pred=Lreg.predict(test_x)
pred
```




    array([40.59446207, 22.42694026, 37.72590599, 28.16405241, 60.6743546 ])




```python
df1=pd.DataFrame({'Actual':test_y,'Predicted': pred})
```


```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>35</td>
      <td>40.594462</td>
    </tr>
    <tr>
      <td>1</td>
      <td>24</td>
      <td>22.426940</td>
    </tr>
    <tr>
      <td>2</td>
      <td>30</td>
      <td>37.725906</td>
    </tr>
    <tr>
      <td>3</td>
      <td>21</td>
      <td>28.164052</td>
    </tr>
    <tr>
      <td>4</td>
      <td>62</td>
      <td>60.674355</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1.shape
```




    (5, 2)




```python
sns.jointplot('Actual','Predicted',data=df1,kind='reg')
```




    <seaborn.axisgrid.JointGrid at 0x1e9d3972d08>




![png](output_30_1.png)


# Finding out the predicted score with 9.5 hours


```python
n=float(input())
hours=np.array([n])
hours=hours.reshape(-1,1)
own_pred=Lreg.predict(hours)
print("No of Hours={}".format(hours))
print("predicted score={}".format(own_pred[0]))
```

    9.5
    No of Hours=[[9.5]]
    predicted score=95.09702749690646
    

# Finding out the accuracy of our model


```python
from sklearn import metrics
print('Mean Absolute error :',metrics.mean_absolute_error(test_y,pred))
print('mean squared error :',metrics.mean_squared_error(test_y,pred))
print('root mean squared error :',np.sqrt(metrics.mean_squared_error(test_y,pred)))
```

    Mean Absolute error : 4.6766251238382335
    mean squared error : 29.308625783942905
    root mean squared error : 5.413744155752367
    
